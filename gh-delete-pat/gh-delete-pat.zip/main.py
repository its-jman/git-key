import requests
import boto3
import os

from base64 import b64decode


def my_decrypt(value):
    return boto3.client('kms').decrypt(CiphertextBlob=b64decode(value))['Plaintext']


client_id = my_decrypt(os.environ['client_id'])
client_secret = my_decrypt(os.environ['client_secret'])


def lambda_handler(event, context):
    pat_token = ''
    print('EVENT', event)
    print('CONTEXT', context)
    #response = requests.delete(
    #    url='https://api.github.com/applications/%s/tokens/%s' % (client_id, pat_token),
    #    auth=(client_id, client_secret)
    #)

    return response
